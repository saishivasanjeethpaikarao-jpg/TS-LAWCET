'use client';

import { useState } from 'react';

export default function HomePage() {
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TS</span>
            </div>
            <span className="text-xl font-bold text-white hidden sm:inline">TS LAWCET</span>
          </div>
          <button className="px-6 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition">
            Get Started
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h1 className="text-5xl sm:text-6xl font-bold text-white mb-6">
          Master <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">TS LAWCET</span>
        </h1>
        <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-8">
          Prepare for Telangana State Law Common Entrance Test with expert guidance, comprehensive materials, and practice tests.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-8 py-3 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition">
            Start Free Trial
          </button>
          <button className="px-8 py-3 border border-slate-600 hover:border-slate-400 text-white rounded-lg font-semibold transition">
            Learn More
          </button>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 sm:grid-cols-3 gap-8">
        <div className="text-center">
          <div className="text-4xl font-bold text-cyan-400 mb-2">10K+</div>
          <p className="text-slate-400">Students Prepared</p>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-cyan-400 mb-2">500+</div>
          <p className="text-slate-400">Practice Questions</p>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-cyan-400 mb-2">95%</div>
          <p className="text-slate-400">Success Rate</p>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-4xl font-bold text-white mb-12 text-center">Why Choose TS LAWCET Prep?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              title: 'Expert Instructors',
              description: 'Learn from experienced law professionals with years of teaching experience.',
              icon: '👨‍🏫'
            },
            {
              title: 'Comprehensive Materials',
              description: 'Access complete study materials covering all topics in the TS LAWCET syllabus.',
              icon: '📚'
            },
            {
              title: 'Practice Tests',
              description: 'Take unlimited mock tests to evaluate your progress and identify weak areas.',
              icon: '📝'
            },
            {
              title: 'Live Classes',
              description: 'Attend interactive live sessions with doubt-clearing and Q&A opportunities.',
              icon: '🎥'
            },
            {
              title: 'Performance Analytics',
              description: 'Get detailed insights into your performance with personalized recommendations.',
              icon: '📊'
            },
            {
              title: '24/7 Support',
              description: 'Get help anytime with our dedicated support team ready to assist you.',
              icon: '💬'
            }
          ].map((feature, index) => (
            <div key={index} className="p-6 rounded-lg border border-slate-800 hover:border-slate-600 transition bg-slate-900/50">
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Pricing Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-4xl font-bold text-white mb-12 text-center">Simple Pricing</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              name: 'Basic',
              price: 'Free',
              features: ['Basic course materials', 'Limited practice questions', 'Community access']
            },
            {
              name: 'Pro',
              price: '₹999/mo',
              features: ['All basic features', 'Unlimited practice tests', 'Video lectures', 'Live classes', 'Performance analytics'],
              highlighted: true
            },
            {
              name: 'Premium',
              price: '₹1,999/mo',
              features: ['All pro features', 'One-on-one mentoring', 'Priority support', 'Doubt clearing sessions', 'Career guidance']
            }
          ].map((plan, index) => (
            <div
              key={index}
              className={`rounded-lg p-8 transition ${
                plan.highlighted
                  ? 'border-2 border-cyan-500 bg-slate-900 shadow-lg shadow-cyan-500/20'
                  : 'border border-slate-800 bg-slate-900/50'
              }`}
            >
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <div className="text-4xl font-bold text-cyan-400 mb-6">{plan.price}</div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center text-slate-300">
                    <span className="text-cyan-400 mr-2">✓</span>
                    {feature}
                  </li>
                ))}
              </ul>
              <button
                className={`w-full py-2 rounded-lg font-semibold transition ${
                  plan.highlighted
                    ? 'bg-cyan-500 hover:bg-cyan-600 text-white'
                    : 'border border-slate-600 hover:border-slate-400 text-white'
                }`}
              >
                Get Started
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h2 className="text-4xl font-bold text-white mb-6">Ready to Ace TS LAWCET?</h2>
        <p className="text-xl text-slate-300 mb-8">Join thousands of successful students. Start your preparation today!</p>
        <button className="px-8 py-3 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition text-lg">
          Start Your Free Trial
        </button>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950/50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-white font-bold mb-4">About</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white transition">About Us</a></li>
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
                <li><a href="#" className="hover:text-white transition">Careers</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Resources</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white transition">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Legal</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white transition">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Follow Us</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white transition">Twitter</a></li>
                <li><a href="#" className="hover:text-white transition">LinkedIn</a></li>
                <li><a href="#" className="hover:text-white transition">Instagram</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-slate-400">
            <p>&copy; 2024 TS LAWCET. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
