import HomePage from './pages/HomePage'
import './App.css'

function App() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <HomePage />
    </main>
  )
}

export default App
