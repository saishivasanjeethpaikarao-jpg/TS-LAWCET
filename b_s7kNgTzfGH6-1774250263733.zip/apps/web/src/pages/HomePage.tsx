export default function HomePage() {
  return (
    <main className="min-h-screen">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-white">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
              TS LAWCET
            </span>
          </div>
          <div className="hidden md:flex gap-8 text-sm">
            <a href="#" className="hover:text-blue-400 transition">
              Home
            </a>
            <a href="#" className="hover:text-blue-400 transition">
              Courses
            </a>
            <a href="#" className="hover:text-blue-400 transition">
              Resources
            </a>
            <a href="#" className="hover:text-blue-400 transition">
              About
            </a>
          </div>
          <button className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-2 rounded-lg hover:shadow-lg hover:shadow-blue-500/50 transition">
            Login
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 text-white">
              Master the
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
                {' '}
                Law Entrance
              </span>
            </h1>
            <p className="text-lg text-gray-300 mb-8">
              Comprehensive preparation for Telangana State Law Common Entrance Test. Expert guidance, practice tests, and proven strategies to help you succeed.
            </p>
            <div className="flex gap-4">
              <button className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-8 py-3 rounded-lg hover:shadow-lg hover:shadow-blue-500/50 transition font-semibold">
                Start Learning
              </button>
              <button className="border border-blue-400 text-blue-400 px-8 py-3 rounded-lg hover:bg-blue-400/10 transition font-semibold">
                Learn More
              </button>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl p-12 backdrop-blur-sm border border-blue-400/30 flex items-center justify-center min-h-80">
            <div className="text-center">
              <div className="text-6xl font-bold text-blue-400 mb-2">98%</div>
              <div className="text-gray-300">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <h2 className="text-4xl font-bold text-center mb-16 text-white">
          Why Choose Us
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              title: 'Expert Instructors',
              description: 'Learn from experienced law professionals and successful LAWCET exam takers',
              icon: '👨‍🏫',
            },
            {
              title: 'Practice Tests',
              description: 'Hundreds of mock exams with detailed solutions and performance analytics',
              icon: '📝',
            },
            {
              title: 'Study Materials',
              description: 'Comprehensive notes, guides, and reference materials for all topics',
              icon: '📚',
            },
          ].map((feature, idx) => (
            <div
              key={idx}
              className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-xl p-8 border border-blue-400/30 hover:border-blue-400/60 transition"
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl p-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Ace Your LAWCET?
          </h2>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of successful students who have used our platform to prepare for their law entrance exam.
          </p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
            Get Started Free
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-20 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="font-bold text-white mb-4">TS LAWCET</div>
              <p className="text-gray-400 text-sm">Your partner in law entrance exam success.</p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Courses
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Practice Tests
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Resources
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Blog
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400 transition">
                    Terms
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-gray-400 text-sm">
            <p>© 2025 TS LAWCET. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
