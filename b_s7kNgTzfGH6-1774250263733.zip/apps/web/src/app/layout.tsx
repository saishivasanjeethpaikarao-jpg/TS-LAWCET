import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'TS LAWCET - Law Entrance Exam Preparation',
  description: 'Prepare for Telangana State Law Common Entrance Test with expert guidance and practice materials',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
